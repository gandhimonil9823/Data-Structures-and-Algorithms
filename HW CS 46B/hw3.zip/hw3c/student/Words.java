import java.util.Scanner;

public class Words
{
   public static void main(String[] args)
   {
      ...
      System.out.println("Words: " + words);
   }
}

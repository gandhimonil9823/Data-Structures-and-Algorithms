import java.util.Comparator;

public class SectionNumberComparator implements Comparator<String> 
{
   ...
}

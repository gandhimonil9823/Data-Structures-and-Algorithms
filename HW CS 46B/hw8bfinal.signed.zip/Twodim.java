public class Twodim
{
	public static void sort(int[][] a)
	{
		for(int i = 0; i < a.length;i++)
		{
			for(int j = 0; j< a[0].length;j++)
			{
				if(i == a.length - 1 && j == a[0].length - 1 )
				{
					return;
				}
				int[] minPos = minimumPosition(a, i, j);
				Twodim.swap(a,minPos[0],minPos[1],i,j);
			}
		}
	}
	/**
      @param a a two-dimensional array
      @param r the starting row
      @param c the starting column
      @return the position of the minimum element in a starting at (r, c)
      as an array [row, column] of length 2 
	 */
	public static int[] minimumPosition(int[][] a, int r, int c)
	{
		int[] array = {r,c};

		for(int i = r ; i < a.length;i++)
		{
			int counter = c+1;
			if(counter >= a[0].length)
			{
				i = i + 1;

				if(i >= a.length)
				{
					i = i - 1;
				}
				counter  = 0 ;
			}

			if(i>r)
			{
				counter = 0;
			}
			for(int j = counter; j < a[0].length;j++)
			{
				if(a[array[0]][array[1]] > a[i][j] )
				{
					array[0] = i; 
					array[1] = j;
				}
			}
		}
		return array;
	}
	public static void swap(int[][] a, int r1, int c1, int r2, int c2)
	{
		int temp = a[r1][c1];
		a[r1][c1] = a[r2][c2];
		a[r2][c2] = temp;
	}

}

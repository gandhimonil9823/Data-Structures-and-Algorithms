/**
 * 
 * @author gandhimonil
 *the ring class links various nodes in a ring shape
 */
public class Ring
{
	Node start; // The current position

	/**
	 * 
	 * @author gandhimonil
	 *sets the nodes at different positions
	 */
	class Node
	{
		Node next;
		Node previous;
		Object data;
	}

	/**
      Construct a ring with the given initial size, and all data set to null.
      @param initialSize the initial size of the ring
	 */
	public Ring(int initialSize)
	{
		if (initialSize <= 0) throw new IllegalArgumentException();
		// Draft: Only needs to work for initialSize == 3
		else
		{

			/**
    	  Node new3 = new Node();
    	 start = new1;
    	   new1.next = new2;
    	   new2.next = new3;
    	   new3.next = new1;
    	   new1.previous= new3;
    	   new3.previous = new2;
    	   new2.previous = new1;
    	  start = new1;
    	  start.next = new2;
    	  start.previous = new3;
			 */


			Node new1 = new Node();

			Node new2 = new Node();

			Node new3 = new Node();
			start = new1;
			new1.next = new2;
			new2.next = new3;
			new3.next = new1;
			new1.previous = new3;
			new3.previous = new2;
			new2.previous = new1;


		}

	}

	/**
      Moves the current position forward.
	 */
	public void forward()
	{
		start = start.next;
	}

	/**
      Moves the current position backward.
	 */
	public void backward()
	{
		start = start.previous;

	}

	/**
      Gets the current element.
      @return the value
	 */
	public Object get()
	{
		return start.data;
	}

	/**
      Sets the current element.
      @param newValue the new value
      @return the old value
	 */
	public Object set(Object newValue)
	{
		Object mo = start.data;
		start.data = newValue;
		return mo;
	}

	/**
      Adds an element before the current element.
      @param newValue the value to add
	 */
	public void add(Object newValue)
	{

	}

	/**
      Removes the current element and makes the next element the current one. 
      @return the old value
	 */
	public Object remove()
	{
		if (start.next == start) throw new IllegalStateException();
		Object removed = start.data;

		// ...

		return removed;
	}
}

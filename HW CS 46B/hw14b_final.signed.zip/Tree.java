import java.util.ArrayList;
import java.util.List;

public class Tree
{  
	private Node root;

	/**
      Constructs a tree with one node and no children.
      @param rootData the data for the root
	 */
	public Tree(Object rootData)
	{
		root = new Node();
		root.data = rootData;
		root.children = new ArrayList<>();
	}

	/**
      Adds a subtree as the last child of the root.
	 */
	public void addSubtree(Tree subtree)
	{
		root.children.add(subtree.root);
	}

	public void print()
	{
		if (root != null) root.print("");
	}

	class Node
	{
		public Object data;
		public List<Node> children;

		public void print(String prefix) 
		{

			/**
			if (prefix.equals(""))
			{
				System.out.println(this.data);
			}   
			for (Node child : children)
			{
				System.out.print(prefix);
				if (!child.children.isEmpty())
				{
                     if(root.children.size() - 1 == children.lastIndexOf(child))
                     {
                    	 prefix = "   ";
                    	 System.out.println (prefix + "+--" + child.data);
                     }
                     else
                     {
					System.out.println ("+--" + child.data);
				    child.print("|  " + prefix);
                     }
				}
				else
				{
					if(prefix.contains("   "))
					{
						prefix = "   " ;
					}
					System.out.println("+--" + child.data);

				}
			 **/

			if (prefix.equals(""))
			{
				System.out.println(this.data);
			}   

			for(Node child : children)
			{

				if (prefix.isEmpty())
				{
					prefix = "+--" ;
				}
				else if(!child.children.isEmpty() && root.children.size()-1 == children.lastIndexOf(child))
				{
					prefix = "   " + prefix;
				}
				else if(child.children.isEmpty() && prefix.contains("   "))
				{
					prefix = "   " + prefix ;
				}
				else
				{
					prefix = "|  "  + prefix;
				}
				System.out.println(prefix + child.data);
				child.print(prefix);
				prefix = prefix.substring(3);

			}



		}
	}

}

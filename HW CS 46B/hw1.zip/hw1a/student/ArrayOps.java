import java.util.ArrayList;

public class ArrayOps
{
   /**
       This method goes through the given array of integers,
       yielding a new ArrayList from the array that contains the
       elements of the original array, with duplicates removed.
       @param theArray, an array of integer
       @return the new ArrayList

   */
   public static ArrayList<Integer> copyArray(int[] anArray)
   {
      // Complete this for the draft

      return null;
   }

   /**
       This method goes through the given array list of integers,
       yielding a new array from the array list that contains the
       elements of the original array list, with duplicates removed.
       @param theArrayList, an array list of integer
       @return the new array

   */
   public static int[] copyArrayList(ArrayList<Integer> anArrayList)
   {
      // Complete this for the final version

      return null;
   }
}

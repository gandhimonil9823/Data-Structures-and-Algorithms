
public class NonEmptyTree implements LispTree
{
	private LispTree left;
	private LispTree right;
	private Object data;

	public NonEmptyTree(Object data, LispTree left, LispTree right)
	{
		this.left = left;
		this.right = right;
		this.data = data;
	}
	public Object data()
	{
		return this.data;
	}
	public LispTree left()
	{
		return this.left;
	}
	public LispTree right()
	{
		return this.right;
	}
	public boolean empty()
	{
		return false; 
	}
	public int height()
	{
		return 1 + Math.max(left.height(),right.height()); 


	}

	public int eval()
	{
		if (!left.empty() && !right.empty())
		{
			int left_value = left.eval();
			int right_value = right.eval();
			if (data == "+")
			{
				return left_value + right_value;
			}
			else if (data.equals("-"))
			{
				return left_value - right_value;
			}
			else if(data.equals("*"))
			{
				return left_value * right_value;
			}
			else if(data.equals("/"))
			{
				return (left_value) / (right_value);
			}
			else if(data.equals("%"))
			{
				return left_value % right_value;
			}
			else
			{
				throw new UnsupportedOperationException();
			}

		}
		else
		{
			return (int) data;
		}

	}
	public String toString()
	{
		if(left.empty() && right.empty())
		{
			return "t(" + data.toString() + ")";
		}
		else
		{
			return "t(" +data.toString() + ", " + left.toString()+ ", " + right.toString()+ ")";
		}

	}
}

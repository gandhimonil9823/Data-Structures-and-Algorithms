import java.util.*;

public class Set
{
	TreeMap<Integer, LinkedList<Object>> buckets;
	// No other instance variables

	/**
      Constructs an empty set.
	 */
	public Set()
	{
		buckets = new TreeMap<Integer, LinkedList<Object>>();// draft
	}

	/**
      Tests for set membership.
      @param x an object
      @return true if x is an element of this set
	 */
	public boolean contains(Object x)
	{
		int num = x.hashCode();
		for(Object mo : buckets.keySet())
		{
			int num1= mo.hashCode();
			LinkedList<Object> list = buckets.get(num); 
			if(num == num1)
			{
				if(list.contains(x))
				{
					return true;
				}

			}

		}
		return false;

	}
	// draft


	/**
      Adds an element to this set.
      @param x an object
      @return true if x is a new object, false if x was
      already in the set
	 */
	public boolean add(Object x)
	{
		int num = x.hashCode();
		LinkedList<Object> obj = new LinkedList<>();
		if(buckets.isEmpty())
		{
			obj.addFirst(x);
			buckets.put(num,obj);
			return true;
		}
		else
		{
			for(Object mo : buckets.keySet())
			{
				int num1= mo.hashCode();
				LinkedList<Object> value = buckets.get(mo); 
				if(num == num1)
				{
					for(int i = 0; i <  value.size(); i++)
					{
						if(value.get(i) == x)
						{
						return false;
						}
					}
						
					value.addFirst(x);
					return false;
				}
				else
				{
					obj.addFirst(x);
					buckets.put(num,obj);
					return true;
				}
			}
		}
		return false;

		/**
		LinkedList<Object> obj = new LinkedList<>();
		if(buckets.contains(x))
		{
			obj.addFirst(x);
			return false;

		}
		else
		{


			obj.addFirst(x);
			buckets.put(x.hashCode(),obj);


			return true;
		}
		 **/
		// draft

	}

	/**
      Gets the number of elements in this set.
      @return the number of elements
	 */
	public int size()
	{
		int resultSize = 0;
		for(Object mo : buckets.keySet())
		{
			int num = mo.hashCode();
			LinkedList<Object> list = buckets.get(num); 
			resultSize = resultSize + list.size();
		}


		return resultSize;
		// draft
	}

	/**
      Removes an object from this set.
      @param x an object
      @return true if x was removed from this set, false
      if x was not an element of this set
	 */
	public boolean remove(Object x)
	{
		return false;
		// final
	}

	/**
      Returns an iterator that traverses the elements of this set.
      @return a hash set iterator
	 */
	public Iterator iterator()
	{
		return new SetIterator();
	}

	class SetIterator implements Iterator
	{
		private Iterator<LinkedList<Object>> bucketIterator;
		private LinkedList<Object> currentBucket;
		private ListIterator<Object> current; 
		// No other instance variables

		/**
         Constructs an iterator that points to the
         first element of the set.
		 */
		public SetIterator()
		{
			// final
		}

		public boolean hasNext()
		{
			// final
			return false;
		}

		public Object next()
		{
			// final
			return null;
		}

		public void remove()
		{
			// final
		}
	}
}



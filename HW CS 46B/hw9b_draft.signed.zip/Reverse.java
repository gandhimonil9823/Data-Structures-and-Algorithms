import java.util.Scanner;
import java.util.Stack;

public class Reverse 
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		Stack<String> stack = new Stack<String>();
        boolean isDot = true;
		
		while(in.hasNextLine() && isDot)
		{
			String str = in.next();
			stack.add(str);
			
			
			if(str.endsWith("."))
			{
                isDot = false;
                str = stack.pop();
				String top = str.replace(".", "");
				 String capitol = top.substring(0, 1).toUpperCase();;
				 top = top.replace(top.substring(0,1), capitol);
				
				stack.add(top);
			}
		}
		while(stack.size()>0)
		{
			String str1 = stack.pop();
			
			
			if(stack.size() == 0)
			{
				System.out.println(str1 + ".");
			}
		
		else
		{
			System.out.print( str1 + " ");
		}
		
		
		
	}


}
}



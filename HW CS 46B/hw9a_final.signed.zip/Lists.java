import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Lists {

    public static ArrayList<String> permutations(String s)
    {
        ArrayList<String> array = new ArrayList<String>();
        Queue <String> q = new LinkedList<String>();
       
        if(s.length() < 1)
        {
           array.add(s);
        }
        q.add("|" + s);

        while(!q.isEmpty())
        {
            String per = q.remove();
            int num = per.indexOf("|");
            String sChanged = per.substring(0, num);
            String t = per.substring(num+1);
            //String[] toSplit = per.split("\\|");
            //String sChanged = toSplit[0];
            //String t = toSplit[1];
            String toAdd = null;
            String toAdd2 = null;
            //System.out.println("t: " +t);
            
            for(int i = 0; i < t.length();i++)
            {
                char c = t.charAt(i);
                int index = t.indexOf(c);
                String removed;
                if(index == 0)
                {
                    removed = t.substring(index + 1);
                }
                else
                {
                    removed = t.substring(0,index) + t.substring(index + 1,t.length());
                }
                toAdd = sChanged+c+removed;
                toAdd2 = sChanged+c+"|"+removed;
//                    q.add(sChanged+c+ "|"+ removed);
                q.add(toAdd2);
                //System.out.println("q:" +q);
            }
            
        }
        array.addAll(q);
        System.out.println("array: " +array);
        return array;
    }

}
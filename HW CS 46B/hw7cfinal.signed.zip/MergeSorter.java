/**
   This class sorts an array, using the merge sort 
   algorithm nonrecursively.
*/
public class MergeSorter
{
	
   /**
      set the length = 1
      while ( length is less then the array's length)
        set the variable starts = 0
         while( starts + length * 2 is less then the array's length)
           if start + length * 2 <= a.length
           merge(start,start +(length-1),start +(2*length-1),a,debug)
           else
           merge(start,start +(length-1),a.length,a,debug);
            start = start + length * 2
             
       length = length * 2;
                
   */
   public static void sort(int[] a, boolean debug)
   {
	   int length = 1; // The size of the sorted regions; a power of 2

	      // while the entire array hasn't yet been sorted
	      while (length < a.length)
	      {
	         int start = 0; // sort starts at the beginning of the array

	         // for each pair of adjacent regions of the given length
	         while (start + length < a.length)
	        {
	        	 if(start + length * 2 <= a.length)
	         merge(start,start +(length-1),start +(2*length-1),a,debug);
	        	 else
	        	 {
	        		 merge(start,start +(length-1),a.length,a,debug);
	        	 }
	            // merge the pair into a sorted region of size 2 * length
	            
	            start = start + length * 2;
	         }
	         length = length * 2;
	      }
	   }


      
   

   /**
      make two arrays
      first one from mid - from + 1
      second one from to - mid
      copy the elements from the array a to the two new arrays
      while (firsti < first.length && secondj < second.length ) // checking which element from both the new arrays is small
      a[from + thirdk] = first[firsti]; coping the smallest elemnt from the two new arrays and pasting t in the arraya
      if one of the arrays runs out of nos then coping the remaining elemnts from the array to the array a.
			  
   */
   public static void merge(int from, int mid, int to, int[] a, boolean debug)
   {
	   if (debug)
	         System.out.println("Merging " + from + "..." + mid 
	            + " and " + (mid + 1) + "..." + to);
	   
	   int[] first = new int[mid - from + 1 ];
	   int[] second = new int [to - mid];
	   
	   for(int i = 0; i < first.length ;i++)
	   {
		   first[i] = a[from + i];
	   }
	   for(int i = 0;i<second.length;i++)
	   {
		   second[i]=a[mid + 1 + i];
	   }
	   int firsti = 0;
	   int secondj = 0;
	   int thirdk = 0;
	   while (firsti < first.length && secondj < second.length )
	   {
		   if(first[firsti] < second[secondj])
		   {
			   a[from + thirdk] = first[firsti];
			   firsti++;
		   }
		   else
		   {
			   a[from + thirdk] = second[secondj];
			   secondj++;
		   }
		   thirdk++;
	   }
	   while(firsti < first.length)
	   {
		   a[from + thirdk] = first[firsti];
		   firsti++;
		   thirdk++;
	   }
	   while(secondj < second.length)
	   {
		   a[thirdk] = second[secondj];
		   secondj++;
		   thirdk++;
	   }
	   


     


   }
}


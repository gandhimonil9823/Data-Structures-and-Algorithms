import java.io.FileNotFoundException;
import java.util.Scanner;

public class Salaries
{
   public static void main(String[] args) throws FileNotFoundException
   {
      String filename = args[0];
      ...
   }
}

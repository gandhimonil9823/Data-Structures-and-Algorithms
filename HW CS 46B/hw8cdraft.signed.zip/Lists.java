import java.util.*;

public class Lists
{
   /**
      Splices the given string before each list element.
      @param a a string
      @param b a list
      @return a list that contains a before each element of b
   */
   public static LinkedList<String> splice(String a, LinkedList<String> b)
   {
	   ListIterator<String> iter = b.listIterator();
	   while (iter.hasNext())
	   {
		   
		   
		   iter.add(a);
		   String nextElement = iter.next();
	        
	       
	        
	        
	        
	        
	        

	   }
	return b;
   
}
}

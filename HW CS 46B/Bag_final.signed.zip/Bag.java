/**
 * creates a bag of elements
 * @author gandhimonil
 *
 */
public class Bag
{
	Node first;
	/**
	 * creates many nodes
	 * @author gandhimonil
	 */
	class Node
	{
		Object data;
		int count;
		Node next;
	}
	/**
	 * constructs a bag of elements
	 */
	public Bag()
	{
		first = null;
	}
	/**
	 * adds a n element
	 * @param obj the object
	 */
	public void add(Object obj)
	{
		if(contains(obj) > 0)
		{

			Node mo = first;
			while(mo.data != obj)
			{
				mo = mo.next;
			}
			mo.count++;
		}
		else
		{
			Node mo = new Node();
			mo.data = obj;
			mo.count = 1;
			mo.next = first;
			first = mo;
		}
	}

	/**
	 * removes an element
	 * @param obj the object
	 */

	public void remove(Object obj)
	{
		Node start = first;

		if(contains(obj) > 0)
		{
			while(start.data != obj )
			{
				start = start.next;
			}
			start.count--;
			if(start.count == 0)
			{
				Node after = new Node();
				Node f = first;

				while(f != start)
				{
					after = f;
					f = f.next;
				}
				Node dec = new Node();
				dec = start.next;
				after.next = dec;
			}

		}
	}


	/**
	 * contains an elements
	 * @param obj the object
	 * @return the integer
	 */
	public int contains(Object obj)
	{
		Node mo = first;  
		while(mo != null)
		{

			if(mo.data == obj)
			{
				return mo.count;
			}

			mo = mo.next;
		}

		return 0;
	}



	/**
	 * creatsa a string 
	 * @return returns a string of elements
	 */


	public String toString()
	{
		String result = "";
		Node done = first;

		if(first != null)
		{
			while(done !=  null)
			{
				if(first.next == null)
				{
					return result = "[" + done.data + "]";
				}

				if( done != null )
				{
					for(int i = 0; i < done.count  ; i++)
					{
						if(i==0)
						{
							if(done == first)
							{
								result = "[" + done.data + ","  + " ";
							}
							else
							{
								if(done.next == null)
								{
									result = result + done.data + "]";
								}
								else
								{
									result = result + done.data+ "," + " ";
								}
							}
						}
						else
						{
							result = result + done.data  + "," +  " ";
						}
					}
					first = done;
				}
				done = done.next;
			}
			return result;
		}
		else
		{
			return "[]";
		}
	}
}




/*
 * int[] a = {1,4,4,1,1,1,5)
 * to_return = ([0,1],[4,1],[4,2],[1,3],[1,4],[1,5],[5,6])
 * sorted to_return = {[0,1],[1,3],[1,4],[1,5],[4,1],[4,2],[5,6])
 * frequency = (1,2,3,4,1,2,1) taking the frequencies of each element
 * value = 1,1,1,1,4,4,5 as i goes from 0 to a.length  
 * frequency[to_return[i].position] = 0,3,4,5,1,2,6 as i goes from 0 to a.length  
 * counter[value] = 4,4,4,4,2,2,1
 * frequency = { 4, 2, 2, 4, 4, 4, 1 }
 */

import java.util.*;

public class Frequency
{
	private static class Element implements Comparable<Element>
	{
		public int value;
		public int position;

		public Element(int value, int position)
		{
			this.value = value;
			this.position = position;
		}

		public int compareTo(Element other) 
		{
			return Integer.compare(value, other.value);
		}
	}

	/**
      Returns an array of the frequencies of each element in a.
      That is, if the returned array is f, then a[i] occurs f[i]
      times in a.
      @return the frequency array
	*/
	public static int[] frequencyOfElements(int[] a)
	{
		int[] frequency = new int[a.length];
		Element[] to_return = new Element[a.length];
		int count = 0;
		int max = 0;

		for(int i = 0; i < a.length;i++)
		{
			to_return[i] = new Element(a[i],i);
			if (a[i] > max) 
				max = a[i];
			
			//counter[a[i]]++;
		}
		Arrays.sort(to_return);

		int[] counter = new int[max+1];
		for (int i = 0; i < a.length; i++) 
		{
			counter[a[i]]++;
		}

		for(int i = 0; i< a.length; i++)
		{
			count++;
			frequency[i] = count;
			if(i == a.length -1 || to_return[i].value != to_return[i+1].value)
			{
				frequency[i] = count;
				count = 0;
			}
		}

		for (int i = 0; i < a.length; i++)
		{
			int value = to_return[i].value;
			frequency[to_return[i].position] = counter[value];
		}
		return frequency;

	}
}
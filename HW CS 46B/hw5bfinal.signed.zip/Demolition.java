

public class Demolition
{
	private int cost;
	private String description;
	private Demolition restDemolition;

	public Demolition(String s)
	{
		if (s.length() <= 1) 
		{
			description = s;
		}
		else
		{
			String wordFirst = s.substring(0, 1);
			String rest = s.substring(1);
			String wordLast = s.substring(s.length()-1, s.length());
			String restWord = s.substring(0, s.length()-1);

			int costFirst = stepCost( wordFirst,rest) + new Demolition(rest).getCost();
			int costSecond = stepCost(wordLast, restWord) + new Demolition(restWord).getCost();
			if(costFirst > costSecond)
			{
				String first = wordLast;
				String rest1 = restWord;
				description = rest1 + " " + first;
				restDemolition = new Demolition(rest1);
				cost = cost + costSecond;
			}
			else
			{
				String first1 = wordFirst;
				String rest2 = rest;
				description = first1 + " " + rest2;
				restDemolition = new Demolition(rest2);
				cost = cost + costFirst;
			}


		}
	}


	public int getCost()
	{
		return cost;
	}

	public static int stepCost(String letter, String rest) 
	{
		return "aeiou".contains(letter) ? 0 : rest.length();
	}

	public String toString()
	{
		if (restDemolition == null) return description;
		else return description + " -> " + restDemolition.toString();
	}
}

/**
 * creates a bag of elements
 * @author gandhimonil
 *
 */
public class Bag
{
	Node first;
/**
 * creates many nodes
 * @author gandhimonil
 */
	class Node
	{
		Object data;
		int count;
		Node next;
	}
/**
 * constructs a bag of elements
 */
	public Bag()
	{
		first = null;
	}
/**
 * adds a n element
 * @param obj the object
 */
	public void add(Object obj)
	{


		if(contains(obj) > 0)
		{
			
			Node mo = first;
			while(mo.data != obj)
			{
				mo = mo.next;
			}
			mo.count++;
		}


		else
		{
			Node mo = new Node();
			mo.data = obj;
			mo.count = 1;
			mo.next = first;
			first = mo;

		}
	}

/**
 * removes an element
 * @param obj the object
 */

	public void remove(Object obj)
	{

	}
/**
 * contsins an elemtns
 * @param obj the object
 * @return the integer
 */
	public int contains(Object obj)
	{
		Node mo = first;  
		while(mo != null)
		{

			if(mo.data == obj)
			{
				return mo.count;
			}

			mo = mo.next;
		}

		return 0;
	}



/**
 * creatsa a string 
 * @return returns a string of elements
 */

	public String toString()
	{
		String result = "[";
		// ...
		return result + "]";
	}
}

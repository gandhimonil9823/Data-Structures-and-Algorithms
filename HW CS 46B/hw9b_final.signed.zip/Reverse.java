import java.util.Scanner;
import java.util.Stack;

public class Reverse 
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		Stack<String> monil = new Stack<String>();
		while(in.hasNext())
		{
			String str = in.next();
			monil.add(str);
			if(str.endsWith("."))
			{
				String nine = str.replace(".", "");
				String nine1 = str.substring(0, 1).toUpperCase();
				String nine2 = nine.replaceFirst(nine.substring(0,1),nine1);
				str = nine2;
				monil.remove(monil.size() - 1);
				monil.add(str);

				while(monil.size()> 0)
				{
					String mo = monil.pop();
					if(monil.size() == 0)
					{
						String moni = mo.substring(0, 1).toLowerCase();
						String moni1 = mo .replace(mo.substring(0,1), moni);
						System.out.print(moni1.trim() + ".");
					}
					else
					{
						System.out.print(" "+ mo + " ");
					}
				}
			}
		}
	}
}












public class Demolition {
	public static int cost(String s) {

		if (s.length() <= 1) {
			return 0;
		} else {
			String wordFirst = s.substring(0, 1);
			String rest = s.substring(1);

			int c1 = stepCost(wordFirst, rest) + cost(rest);

			String wordLast = s.substring(s.length()-1, s.length());
			String restWord = s.substring(0, s.length()-1);

			int c2 = stepCost(wordLast, restWord) + cost(restWord);
			return Math.min(c1, c2);

		}
	}

	public static int stepCost(String letter, String rest) {
		return "aeiou".contains(letter) ? 0 : rest.length();
	}
}

import java.util.*;

public class Lists
{
	/**
      Splices the given string before each list element.
      @param a a string
      @param b a list
      @return a list that contains a before each element of b
	 */
	public static LinkedList<String> splice(String a, LinkedList<String> b)
	{
		ListIterator<String> iter = b.listIterator();
		while (iter.hasNext())
		{
			iter.add(a);
			String nextElement = iter.next();
		}
		return b;

	}

	/**
      Splices the given lists.
      @param a a list
      @param b a list
      @return a list that contains alternating elements of a and b, 
      and if one list is longer than the other, the tail of the 
      longer list
	 */
	public static LinkedList<String> splice(LinkedList<String> a, LinkedList<String> b)
	{
		LinkedList<String> veryImp = new LinkedList<>();
		ListIterator<String> iter = a.listIterator();
		ListIterator<String>iter2 = b.listIterator();
		while(iter.hasNext() && iter2.hasNext())
		{
			String word = iter.next();
			String other_Word = iter2.next();
			veryImp.addLast(word);
			veryImp.addLast(other_Word);
		}
		if (a.size() > b.size())
		{
			while(iter.hasNext())
			{
				String big_word = iter.next();
				veryImp.addLast(big_word);
			}
		}
		else if(b.size() > a.size())
		{

			while(iter2.hasNext())
			{  
				String big_big = iter2.next();
				veryImp.addLast(big_big);
			}
		}
		else
		{
			return veryImp;
		}
		return veryImp;

	}

	/**
      Removes all elements from b that end in the string a
      @param a a string
      @param b a list
	 */
	public static void removeEndingWith(String a, LinkedList<String> b)
	{
		ListIterator<String> iter = b.listIterator();
		{
			while(iter.hasNext())
			{
				String word_last = iter.next();
				if(word_last.contains(a))
				{
					iter.remove();
				}

			}
		}
	}
}


public class Puzzle 
{
   private String add1;
   private String add2;
   private String result;

   /**
      Constructs a puzzle.
      @param add1 a string containing digits 0 - 9 and letters
      @param add2 a string containing digits 0 - 9 and letters
      @param result a string containing digits 0 - 9 and letters
   */
   public Puzzle(String add1, String add2, String result) 
   {
      this.add1 = add1;
      this.add2 = add2;
      this.result = result;
   }
   
   /**
      Makes a new puzzle by replacing a letter with a digit.
      @param letter the letter to be replaced
      @param digit the digit to replace it with
      @return the new puzzle
   */
   public Puzzle replace(String letter, int digit)
   { 
	   
	   
	   String theString  = Integer.toString(digit);
	   this.add1 = add1.replace(letter, theString);
	   this.add2 = add2.replace(letter, theString);
	   this.result = result.replace(letter, theString);
	   
	   
	  
	  
      return this;
      
   }

   /**
      Gets the first letter in this puzzle.
      @return the first letter, or "" if there are no letters.
   */
   public String firstLetter()
   {
	   String loop = add1 + add2 + result;
	   String word = "";
	   int count = 0;
	   while(count < loop.length())
		   
	   {
		  char c = loop.charAt(count);
		   if(Character.isLetter(c))
		   {
			   word = Character.toString(c);
			   return word;
		   }
		   else
		   {
			   count++;
		   }
		   
	   }
	   return word;
	   
        }

   /**
      Returns true if the puzzle is solved.
      @return true if the puzzle has no letters, no number starts
      with zero, and the first two numbers add up to the third
   */
   public boolean isSolved() 
   {
	   String mo = add1.substring(0,1);
	   int mo2 = Integer.parseInt(mo);
	   String mo3 = add2.substring(0,1);
	   int mo4 = Integer.parseInt(mo3);
	   String mo5 = result.substring(0,1);
	   int mo6 = Integer.parseInt(mo5);
	   if( mo2 == 0 )
		   
		   
	   {
		   return false;
	   }
	   else if(mo4 == 0)
     {
    	 return false;
     }
	   else  if(mo6 == 0)
	   {
		   return false;
	   }
	   else
	   {
		   return false;
	   }
     
     
   }

   /**
      Checks whether this puzzle contains a given digit.
      @param digit a digit
      @return true if this puzzle returns digit
   */
   public boolean contains(int digit)
   {
      return false;
   }
    
   public String toString()
   {
      return add1 + "+" + add2 + "=" + result;
   }    
}
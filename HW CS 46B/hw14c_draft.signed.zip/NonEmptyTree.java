
public class NonEmptyTree implements LispTree
{
	private LispTree left;
	private LispTree right;
	private Object data;

	public NonEmptyTree(Object data, LispTree left, LispTree right)
	{
		this.left = left;
		this.right = right;
		this.data = data;
	}
	public Object data()
	{
		return this.data;
	}
	public LispTree left()
	{
		return this.left;
	}
	public LispTree right()
	{
		return this.right;
	}
	public boolean empty()
	{
		return false; 
	}
	public String toString()
	{
		if(left.empty() && right.empty())
		{
			return "t(" + data.toString() + ")";
		}
		else
		{
			return "t(" +data.toString() + ", " + left.toString()+ ", " + right.toString()+ ")";
		}

	}
}

/*
 * int[] numbers = {5,9,7,5,9};
 * j = 0; i = 0, a[i] = 5,a[j] = 0
 * if(a[i] = a[j])(5 = 5), Therefore, counter = 1
 * j = 1, a[j] = 9.
 * 5 =/ 9 , counter = 1;
 * j = 2 , a[j] = 7.
 * 5 =/ 7 , counter = 1;
 * j = 3 , a[j] = 5;
 * 5 = 5 ; counter = 2;
 * j = 4; a[j] = 9;
 * 5 =/ 9; counter = 2;
 * counter = f[i] - where f is a new array to return.
 * 
 */


import java.util.Arrays;

public class Frequency {
	
		  /**
		     Returns an array of the frequencies of each element in a.
		     That is, if the returned array is f, then a[i] occurs f[i]
		     times in a.
		     @return the frequency array
		  */
		  public static int[] frequencyOfElements(int[] a)
		  {
			  int[] f = new int[a.length];
			  
			  for(int i = 0; i < a.length; i++)
			  {
				  int counter = 0;
				  
				  
				  for(int j = 0 ; j <a.length;j++)
				  {
					  if(a[i] == a[j])
					  {
						  counter ++;
					  }
					  
					  
				  }
				   f[i] = counter; 
					  
			  }
			  
			return f;
		     
		  }
}
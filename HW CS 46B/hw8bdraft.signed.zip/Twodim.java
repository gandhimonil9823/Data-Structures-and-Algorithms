public class Twodim
{
	/**
      @param a a two-dimensional array
      @param r the starting row
      @param c the starting column
      @return the position of the minimum element in a starting at (r, c)
      as an array [row, column] of length 2 
	 */
	public static int[] minimumPosition(int[][] a, int r, int c)
	{
		int[] array = {r,c};

		for(int i = r ; i < a.length;i++)
		{
			int counter = c+1;

			if(i>r)
			{
				counter = c;
			}

			for(int j = counter; j < a[0].length;j++)
			{
				if(a[array[0]][array[1]] > a[i][j] )
				{

					array[0] = i; 
					array[1] = j;

				}


			}



		}
		return array;

	}
}

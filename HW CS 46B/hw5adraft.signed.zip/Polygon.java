

import java.awt.geom.Point2D;
import java.util.ArrayList;

/**
   A polygon with a number of Point2D.Double corners
*/
public class Polygon
{
   private ArrayList<Point2D.Double> corners;

   /**
      Constructs a Polygon object with no corners
   */
   public Polygon()
   {
      corners = new ArrayList<Point2D.Double>();
   }
  
   /**
      Adds a point to the list.
      @param p the point to add
   */
   public void add(Point2D.Double p)
   {
      corners.add(p);   
   }
   
   /**
      Computes the area of a polygon.
      @return area of a polygon
   */
   public double getArea()
   {
	   
      Point2D.Double  triangle1 = corners.get(1);
      double x1 = triangle1.getX();
      double y1 = triangle1.getY();
      Point2D.Double  triangle2 = corners.get(2);
      double x2 = triangle2.getX();
      double y2 = triangle2.getY();
      Point2D.Double  triangle3 = corners.get(3);
      double x3 = triangle3.getX();
      double y3 = triangle3.getY();
      
      double theArea = Math.abs((x1 * y2) + (x2 * y3) + (x3 * y1) - (y1 * x2) - (y2 * x3) - (y3 * x1)) / 2;
    		  return theArea;
    		  
	   
      
   }
}


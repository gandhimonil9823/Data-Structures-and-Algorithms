import java.util.ArrayList;
public class MultiChoiceQuestion extends ChoiceQuestion
{
	private ArrayList<String>choices;
	private String answer;
	int correctChoices;

	public MultiChoiceQuestion()
	{
		answer = "";
		choices = new ArrayList<String>();
		correctChoices =0;
	}
	public void addChoice(String choice, boolean correct)
	{
		super.addChoice(choice,correct);

		correctChoices++;

		if (correct) 
		{
			answer = answer + " " + correctChoices;
			String last = answer.trim();
			setAnswer(last);

		}
	}
	public void display()
	{
		// Display the question text
		super.display();

		System.out.println("Enter all correct choices separated by spaces.");     
	}
}


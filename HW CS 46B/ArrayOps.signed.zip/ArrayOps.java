import java.util.ArrayList;

public class ArrayOps
{
    /**
    This method goes through the given array of integers,
    yielding a new ArrayList from the array that contains the
    elements of the original array, with duplicates removed.
    @param theArray, an array of integer
    @return the new ArrayList

     */

    public static ArrayList<Integer> copyArray(int[] anArray)
    {

        
        ArrayList<Integer> newArrayList = new ArrayList<Integer>(anArray.length);
        for (Integer adding: anArray)
        {
            newArrayList.add(adding);
        }
        for (int i = 0; i < newArrayList.size(); i++)
        {
            for (int j = i + 1; j < newArrayList.size(); j++)
            {
                if (newArrayList.get(i) == newArrayList.get(j))
                {
                    newArrayList.remove(j);
                    j--;

                }
            }
        }
        return newArrayList;
    }

 
           
          
}



   

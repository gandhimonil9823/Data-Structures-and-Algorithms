import java.awt.Rectangle;
/**
 * Write a description of class BetterRectangle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BetterRectangle extends Rectangle
{

    
    public BetterRectangle(int x, int y,int width, int height)
    {
        super.setLocation(x,y);
        super.setSize(width,height);
    }

    public int getPerimeter()
    {

        int perimeter = 2 * (height + width);
        return perimeter;
    }

    public int getArea()
    {

        int area = height * width;
        return area;
    }

    public void grow(int m , int n )
    {
        height = height+ 2*m;
        width = width + 2*n;
    }

    
}

    
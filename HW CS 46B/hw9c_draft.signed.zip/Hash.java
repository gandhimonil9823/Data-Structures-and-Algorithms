
import java.util.HashSet;
import java.util.Scanner;

public class Hash 
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		HashSet<String> name = new HashSet<String>();
		while(in.hasNext())
		{
			String str = in.next();
			int num = str.hashCode();
			System.out.println(num + ": " + str);
		}
	}
}
